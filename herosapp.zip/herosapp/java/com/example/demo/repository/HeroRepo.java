package com.example.demo.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Hero;
@Repository
public interface HeroRepo extends JpaRepository<Hero,Object> {
	
	//List<Hero> findByfnameStartsWith(String fname);
	@Query(value="select * from hero h",nativeQuery=true)
	List<Hero> findHeros();
	@Query(value="select * from hero h where h.id BETWEEN 1 AND 4",nativeQuery=true)
	List<Hero> filter();
	
}
