package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.demo.model.Hero;
import com.example.demo.repository.HeroRepo;
@Service
public class Heroservice {

	
	@Autowired
	private HeroRepo Herorepo;
	
	public  void createHero( Hero hero) {
		// TODO Auto-generated method stub
		
		  Herorepo.save(hero);
	}

	public List<Hero> getHeroes() {
		// TODO Auto-generated method stub
		
		return  Herorepo.findHeros();
	}

	public Optional<Hero> getHeroById(int id) {
		// TODO Auto-generated method stub
		Optional<Hero> h=Herorepo.findById(id);
		return h;
	}

	public void deleteById(int id) {
		// TODO Auto-generated method stub
		Herorepo.deleteById(id);
	}

	public List<Hero> getTopHeros() {
		// TODO Auto-generated method stub
		return Herorepo.filter();
	}

	/*public List<Hero> getHeroStartsWith(String name) {
		// TODO Auto-generated method stub
		return Herorepo.findByfnameStartsWith(name);
	}*/
	

}
