package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Hero;
import com.example.demo.model.User;
import com.example.demo.service.Heroservice;

//import com.cognizant.modal.User;
@Component
@RestController
@CrossOrigin(origins ="http://localhost:3000")
public class HeroController {
	
	
	private static final Logger log = LoggerFactory.getLogger(HeroController.class);

	@Autowired
	
	private Heroservice Heroservice;
	
	@PostMapping("/heros")
	public ResponseEntity<Void> createHero(@Valid@RequestBody Hero hero)
	{
		
		  Heroservice.createHero(hero);
		  
		//return hero.getId();
		return new ResponseEntity<>(HttpStatus.ACCEPTED);
		
	}
	//@CrossOrigin(origins ="http://localhost:3000")
	@GetMapping("/heros")
	public ResponseEntity<List<Hero>> viewHero()
	{
		List<Hero> h=Heroservice.getHeroes();
		HttpHeaders header=new HttpHeaders();
		header.add("description", "getting list of heros");
		return new ResponseEntity<List<Hero>>(h, header,HttpStatus.OK);
	}
	
	@GetMapping("/heros/{id}")
	public ResponseEntity<Optional<Hero>> viewHeroById(@PathVariable("id") int id)
	{
		
		
			Optional<Hero> h1=Heroservice.getHeroById(id);
			HttpHeaders header=new HttpHeaders();
			header.add("description", "getting heros by id");
			return new ResponseEntity<Optional<Hero>>(h1,header,HttpStatus.OK);
		
	}
	@DeleteMapping("/heros/{id}")
	public ResponseEntity<Void> deleteStudent(@PathVariable int id) {
		
			Heroservice.deleteById(id);
		return new ResponseEntity<>(HttpStatus.OK);
		}
	
	//@CrossOrigin(origins ="http://localhost:3000")
	@GetMapping("/topheros")
	public ResponseEntity<List<Hero>> getTopHeros()
	{
		List<Hero> h=Heroservice.getTopHeros();
		HttpHeaders header=new HttpHeaders();
		header.add("description", "getting list of top heros");
		return new ResponseEntity<List<Hero>>(h, header,HttpStatus.OK);
	}
	@PutMapping("/heros")
	public ResponseEntity<Void> updateHero(@RequestBody Hero hero)
	{
		
		Heroservice.updateHero(hero);
		return new ResponseEntity<>(HttpStatus.OK);
		
		
	}
	
	@PostMapping("/login")
	public String success(@RequestBody User user, HttpSession session)
	{
		log.info("inside loginmethod");
	    return  Heroservice.validate(user, session);
	    
	}
	
	@PostMapping("/adduser")
	public String AddUser(@RequestBody User user,HttpSession session)
	{
		log.info("inside add user");
		return Heroservice.AddUser(user,session);
	}
	
	
	
	
	
}
