package com.example.demo.service;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.demo.model.AuthResponse;
import com.example.demo.model.Hero;
import com.example.demo.model.User;
import com.example.demo.repository.HeroRepo;
@Service
public class Heroservice {

	private static final Logger log = LoggerFactory.getLogger(Heroservice.class);

	@Autowired
	private HeroRepo Herorepo;
	
	public  void createHero( @Valid Hero hero) {
		// TODO Auto-generated method stub
		
		  Herorepo.save(hero);
	}

	public List<Hero> getHeroes() {
		// TODO Auto-generated method stub
		
		return  Herorepo.findHeros();
	}

	public Optional<Hero> getHeroById(int id) {
		// TODO Auto-generated method stub
		Optional<Hero> h=Herorepo.findById(id);
		return h;
	}

	public void deleteById(int id) {
		// TODO Auto-generated method stub
		Herorepo.deleteById(id);
	}

	public List<Hero> getTopHeros() {
		// TODO Auto-generated method stub
		return Herorepo.filter();
	}

	public void updateHero(Hero hero) {
		// TODO Auto-generated method stub
		Herorepo.save(hero);
	}
	public String  validate(User user, HttpSession session) {
		User userobj=null;
		RestTemplate restTemplate=new RestTemplate();
		try {
			userobj=restTemplate.postForObject("http://localhost:8090/authapp/login", user, User.class);
			log.info("inside validate success");
		}
		catch(Exception e)
		{
			log.info("inside validate error");
			String error="";
			error="Unable to login. please check your credentials.";
			log.info("inside validate error2");
			//model.put("error", error);
			return error;
		}
		session.setAttribute("token", userobj.getAuthToken());
		session.setAttribute("memberId", userobj.getUserid());
		return getWelcome((String) session.getAttribute("token"),user);
	}
	public String getWelcome(String token,User user) {

		 RestTemplate restTemplate=new RestTemplate();
		try {
		HttpHeaders headers = new HttpHeaders();
		headers.add("Authorization", "Bearer " + token);
		@SuppressWarnings({ "rawtypes", "unchecked" })
		HttpEntity request = new HttpEntity(headers);
		ResponseEntity<AuthResponse> response = restTemplate.exchange("http://localhost:8090/authapp/validate", HttpMethod.GET, request, AuthResponse.class);
		AuthResponse account = response.getBody();
		} catch (Exception e) {
		String error="";
		error="Unable to login. please check your credentials.";
		//throw new IdException(error);
		return error;
		}
		URI location= ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}")
		.buildAndExpand(user.getUserid()).toUri();
		return "success";

		 }

	public String AddUser(User user,HttpSession session) {
		try
		{
		RestTemplate restTemplate1=new RestTemplate();
		User userobj=restTemplate1.postForObject("http://localhost:8090/authapp/adduser",user,User.class);
		String details="Hi "+user.getUname()+" Your details has been added to db successfully!..";
		//model.put("details",details);
		return "login";
		}catch(Exception e)
		{
			String details="UserId is Already in use!.. Try with another userID!..";
			//model.put("details",details);
			return "login";
		}
	}
	

}
