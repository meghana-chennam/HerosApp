insert into hero(id,fname) values(1,'magneta');
insert into hero(id,fname) values(2,'Dynamo');
insert into hero(id,fname) values(3,'DrIq');
insert into hero(id,fname) values(4,'BatsMan');
insert into hero(id,fname) values(5,'PowerRanger');
insert into hero(id,fname) values(6,'Shakthi');
insert into hero(id,fname) values(7,'Meghana');
insert into hero(id,fname) values(8,'Ironman');