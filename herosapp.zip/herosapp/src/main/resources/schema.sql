
create table hero(id int primary key,fname varchar(30));